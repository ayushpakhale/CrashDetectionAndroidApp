package com.example.nav;

class constants {
    static final int LOCATION_SERVICE_ID = 175;
    static final String ACTION_START_LOCATION_SERVICE = "startLocationService";

    static final String sendlat = "sendlat";
    static final String sendlon = "sendlon";
    static final String ACTION_STOP_LOCATION_SERVICE = "stopLocationService";


    //fragment_profile here

    static final String NAME1 = "name1";
    static final String NAME2 = "name2";
    static final String CONTACT1 = "contact1";
    static final String CONTACT2 = "contact2";
    static final String SHARED_PREFS ="sharedprefs";



    //main activity here
    static final String XNAME1 = "xname1";
    static final String XNAME2 = "xname2";
    static final String XCONTACT1 = "xcontact1";
    static final String XCONTACT2 = "xcontact2";
    static final String XSHARED_PREFS ="xsharedprefs";
}


